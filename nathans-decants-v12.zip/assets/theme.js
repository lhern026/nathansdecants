/*
  Nathan's Decants — Motion Choreography & Interactions
  GPU-safe: Only animates transform and opacity
*/

document.addEventListener('DOMContentLoaded', () => {

  /* ==============================
     1. HAMBURGER MENU
     ============================== */
  const hamburger = document.querySelector('.hamburger');
  const mobileNav = document.querySelector('.mobile-nav');
  const closeBtn = document.querySelector('.mobile-nav__close');
  const navLinks = document.querySelectorAll('.mobile-nav__link');

  function openMenu() {
    if (!mobileNav) return;
    hamburger.classList.add('is-active');
    mobileNav.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    navLinks.forEach((link, i) => {
      link.style.transitionDelay = `${150 + i * 60}ms`;
    });
  }

  function closeMenu() {
    if (!mobileNav) return;
    hamburger.classList.remove('is-active');
    mobileNav.classList.remove('is-open');
    document.body.style.overflow = '';
    navLinks.forEach(link => {
      link.style.transitionDelay = '0ms';
    });
  }

  if (hamburger) hamburger.addEventListener('click', openMenu);
  if (closeBtn) closeBtn.addEventListener('click', closeMenu);

  /* ==============================
     2. SCROLL REVEAL (IntersectionObserver)
     ============================== */
  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.08, rootMargin: '0px 0px -80px 0px' }
  );

  document.querySelectorAll('.reveal').forEach((el, i) => {
    if (el.closest('.product-grid')) {
      el.style.transitionDelay = `${(i % 3) * 120}ms`;
    }
    revealObserver.observe(el);
  });

  /* ==============================
     3. HEADER HIDE/SHOW ON SCROLL
     ============================== */
  const header = document.querySelector('.site-header');
  let lastScrollY = 0;
  let ticking = false;

  function onScroll() {
    if (!header) return;
    const currentY = window.pageYOffset;
    if (currentY > lastScrollY && currentY > 100) {
      header.classList.add('is-hidden');
    } else {
      header.classList.remove('is-hidden');
    }
    lastScrollY = currentY;
    ticking = false;
  }

  window.addEventListener('scroll', () => {
    if (!ticking) {
      window.requestAnimationFrame(onScroll);
      ticking = true;
    }
  }, { passive: true });

  /* ==============================
     4. CART DRAWER
     ============================== */
  const cartTriggers = document.querySelectorAll('.js-cart-drawer-trigger');
  const cartClosers = document.querySelectorAll('.js-cart-drawer-close');
  const cartDrawer = document.getElementById('CartDrawer');
  const cartOverlay = document.querySelector('.cart-drawer-overlay');

  function openCart(e) {
    if (e) e.preventDefault();
    if (!cartDrawer) return;
    cartDrawer.classList.add('is-active');
    if (cartOverlay) cartOverlay.classList.add('is-active');
    document.body.style.overflow = 'hidden';
  }

  function closeCart() {
    if (!cartDrawer) return;
    cartDrawer.classList.remove('is-active');
    if (cartOverlay) cartOverlay.classList.remove('is-active');
    document.body.style.overflow = '';
  }

  cartTriggers.forEach(btn => btn.addEventListener('click', openCart));
  cartClosers.forEach(btn => btn.addEventListener('click', closeCart));

  /* ==============================
     5. CART QUANTITY +/- BUTTONS
     ============================== */
  document.querySelectorAll('.js-qty-minus').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.closest('.cart-qty-control').querySelector('.cart-qty-input');
      const val = parseInt(input.value, 10);
      if (val > 0) input.value = val - 1;
    });
  });

  document.querySelectorAll('.js-qty-plus').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.closest('.cart-qty-control').querySelector('.cart-qty-input');
      input.value = parseInt(input.value, 10) + 1;
    });
  });

});
