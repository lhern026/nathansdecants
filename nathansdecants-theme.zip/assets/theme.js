/* 
  Nathan's Decants: High-End Motion Choreography
*/

document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Mobile Menu Logic with Staggered Links
    const hamburger = document.querySelector('.hamburger');
    const mobileNav = document.querySelector('.mobile-nav');
    const closeBtn = document.querySelector('.mobile-nav__close');
    const navLinks = document.querySelectorAll('.mobile-nav__link');

    const toggleMenu = (isOpen) => {
        if (isOpen) {
            mobileNav.classList.add('is-open');
            document.body.style.overflow = 'hidden';
            navLinks.forEach((link, index) => {
                link.style.transitionDelay = `${100 + (index * 50)}ms`;
            });
        } else {
            mobileNav.classList.remove('is-open');
            document.body.style.overflow = '';
            navLinks.forEach(link => link.style.transitionDelay = '0ms');
        }
    };

    if (hamburger) hamburger.addEventListener('click', () => toggleMenu(true));
    if (closeBtn) closeBtn.addEventListener('click', () => toggleMenu(false));

    // 2. Intersection Observer for Entry Animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                // Unobserve once animation is triggered
                revealObserver.unobserve(entry.target);
            }
        });
    }, observerOptions);

    const revealElements = document.querySelectorAll('.reveal');
    revealElements.forEach((el, index) => {
        // Add a slight stagger to elements in the same grid
        if (el.classList.contains('product-card')) {
            el.style.transitionDelay = `${(index % 3) * 100}ms`;
        }
        revealObserver.observe(el);
    });

    // 3. Magnetic Header Effect
    let lastScroll = 0;
    const header = document.querySelector('header');
    
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        if (currentScroll <= 0) {
            header.style.transform = 'translateX(-50%)';
            return;
        }

        if (currentScroll > lastScroll && currentScroll > 100) {
            // Scrolling down
            header.style.transform = 'translate(-50%, -150%)';
        } else {
            // Scrolling up
            header.style.transform = 'translateX(-50%) scale(1)';
        }
        lastScroll = currentScroll;
    }, { passive: true });

});
